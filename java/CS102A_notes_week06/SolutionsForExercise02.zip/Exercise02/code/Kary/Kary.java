public class Kary {   // Kary.java
   public static void main (String[] args) {
      long n = Long.parseLong( args[0] );
      int  k = Integer.parseInt( args[1] );
      
      System.out.println( long2Digits( n, k ) );
   }

   public static String long2Digits (long n, int k) {
      String DIGITS = "0123456789ABCDEF";
      if (n == 0L) return "0";
      
      String s = "";
      while (n != 0L) {
         int r = (int)(n % k);
         s = DIGITS.charAt(r) + s;
         // s = DIGITS.substring(r, r+1) + s;
         n = n / k;
      }
      
      return s;
   }
}
