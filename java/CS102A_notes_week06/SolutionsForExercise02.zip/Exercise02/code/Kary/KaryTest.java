public class KaryTest {   
   public static void main (String[] args) {
      String[] sNum = { "19", "100000000", "9223372036854775807" };
      for (int k = 2; k <= 16; k++) {
         String[] s = new String[2];
         s[1] = "" + k;
         
         for (int i = 0; i < sNum.length; i++) {
            s[0] = sNum[i];
            System.out.printf( "Kary %s %s ==>\n", s[0], s[1] );
            Kary.main( s );
         }
      }
   }
}
