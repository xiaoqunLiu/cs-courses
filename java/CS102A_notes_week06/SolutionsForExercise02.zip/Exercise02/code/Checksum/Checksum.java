public class Checksum {   
   public static void main (String[] args) {
      String isbn = args[0];
      System.out.println( isbnWithChecksum( isbn ) );
   }

   public static String isbnWithChecksum (String isbn) {
      int sum = 0;
      for (int i = 0; i < 9; i++)
         sum += (10-i) * (int)(isbn.charAt(i) - '0');
      int checksum = (11 - sum % 11) % 11;
      return isbn + ((checksum == 10) ? "X" : "" + checksum);   
   }
}