public class E02Q1_3_9 {   // Print Integers
   public static void main (String[] args) {
      for (int i = 1000; i <= 2000; i++) {
         System.out.print( i );
         if (i%5 != 4)
             System.out.print( "\t" );
         else
             System.out.print( "\n" );
         // System.out.print( i%5 != 4 ? "\t" : "\n" );
      }   
   }
}
