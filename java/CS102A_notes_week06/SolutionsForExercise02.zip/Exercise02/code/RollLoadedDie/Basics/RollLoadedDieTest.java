// Exercise02/RollLoadedDie/Basics/RollLoadedDieTest.java
public class RollLoadedDieTest {   
   public static void main (String[] args) {
      int N = Integer.parseInt( args[0] );
      for (int i = 0; i < N; i++)
         RollLoadedDie.main( null );
   }
}
