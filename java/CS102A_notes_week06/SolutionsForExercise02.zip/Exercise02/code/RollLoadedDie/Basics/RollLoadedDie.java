// Exercise02/RollLoadedDie/Basics/RollLoadedDie.java
public class RollLoadedDie {   
   public static void main (String[] args) {
      int die = 1 + (int)(Math.random() * 8);
      if (die > 6) die = 6;
      System.out.println( die );
   }
}
