// Exercise02/RollLoadedDie/withTest/RollLoadedDie.java
public class RollLoadedDie {   
   public static void main (String[] args) {
      System.out.println( rollDie() );
   }

   public static int rollDie () {
      int die = 1 + (int)(Math.random() * 8);
      if (die > 6) die = 6;
      return die;
   }
}
