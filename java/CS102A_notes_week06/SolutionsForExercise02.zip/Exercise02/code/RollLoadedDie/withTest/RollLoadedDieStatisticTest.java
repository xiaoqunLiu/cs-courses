// Exercise02/RollLoadedDie/withTest/RollLoadedDieStatisticTest.java
public class RollLoadedDieStatisticTest {   
   public static void main (String[] args) {
      String[][] s = { 
         {"1000"}, {"10000"}, {"100000"}, {"100000"}, {"1000000"},
         {"10000000"}, {"1000000000"}
      };
      
      for (int i = 0; i < s.length; i++) {
         System.out.println( "RollLoadedDieStatistic " + s[i][0] );
         RollLoadedDieStatistic.main( s[i] );
      }
   }
}
