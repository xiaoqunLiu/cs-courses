import java.time.*;     // JDK 8.0+, Instant, Duration ...

public class PrimeCounterTimeTest {   
   public static void main (String[] args) {
      int N = Integer.parseInt( args[0] );

      Instant start = Instant.now();

      int count = PrimeCounter.numberOfPrimes( N );

      Instant end = Instant.now();
      long t = Duration.between(start, end).toMillis();

      System.out.printf( "%d Prime%s in [1..%d], with %d ms\n", 
         count, (count<=1 ? "" : "s"), N, t 
      );
   }
}
