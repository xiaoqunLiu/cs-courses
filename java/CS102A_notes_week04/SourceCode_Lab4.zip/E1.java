import java.util.Scanner;

// Computing the GPA, first method

public class E1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double  grade;
        double  gpa;
        int     range;

        System.out.print("Please input a grade: ");
        try {
          grade = sc.nextDouble();
          if ((grade <= 100.0) && (grade >= 0f)) {
            if (grade >= 90) {
               gpa = 4.0;
            } else if (grade >= 80) {
               gpa = 3.0;
            } else if (grade >= 70) { 
               gpa = 2.0;
            } else if (grade >= 60) { 
               gpa = 1.0;
            } else { 
               gpa = 0.0;
            }
            System.out.printf("Your grade %.1f, the corresponding GPA is %.1f%n", grade, gpa);
          } else {
            System.err.println("Invalid grade - must be between 0 and 100");
          }
        } catch (Exception e) {
           System.err.println("Invalid input");
        }
    }
}
