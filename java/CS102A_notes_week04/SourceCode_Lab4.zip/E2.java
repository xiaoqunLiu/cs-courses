import java.util.Scanner;
import java.util.Random;

// Number guessing, very dull version. Make sure you understand
// what happens if people type in a letter.
//
public class E2 {

	public static void main(String[] x) {
		Scanner sc = new Scanner(System.in);
		Random rnd = new Random();
		int magicNum = rnd.nextInt(10);
		int guess = -1;

		System.out.println("Please input an integer between 0 and 9:");
		while (guess != magicNum) {
			try {
				guess = sc.nextInt();
			} catch (Exception e) {
				sc.nextLine();
				guess = -1;
			}
			if (guess > magicNum) {
				System.out.println("Too high!Please try again: ");
			} else if (guess < magicNum) {
				System.out.println("Too low!Please try again: ");
			}
		}
		System.out.println("Congratulations!");
	}

}
