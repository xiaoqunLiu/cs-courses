import java.util.Scanner;

public class E3 {

    public static void main(String[] x) {
        Scanner sc = new Scanner(System.in);
        double myPi = 4.0;
        double prevPi = 0.0;
        double precision;

        System.out.println("Please input a precision:");
        try {
          precision = sc.nextDouble();
          long i = 0;
          while (Math.abs(myPi - prevPi) > precision) {
            prevPi = myPi;
            myPi += ((i % 2 == 0) ? -1 : 1)
                    * (4.0 / (3 + i*2));
            i++;
          }
          System.out.println(myPi);
          System.out.println(i + " iterations");

        } catch (Exception e) {
          System.err.println("Invalid input");
        }
    }
}
