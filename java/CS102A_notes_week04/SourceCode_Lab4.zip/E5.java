
public class E5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N = Integer.parseInt(args[0]);
		int V = Integer.parseInt(args[1]);
		StringBuilder sb_q = new StringBuilder("Questions:\n");
		StringBuilder sb_a = new StringBuilder("Answer:\n");
		

		int count = 0;
		while (count < V) {
			double r1 = Math.random();
			int t1 = (int) (r1 * N);

			double r2 = Math.random();
			int t2 = (int) (r2 * N);

			int result = 0;

			int op_index = (int) (Math.random() * 5);
			String op =" ";

			switch (op_index) {
			case 0:
				result = t1 + t2;
				op = " + ";
				break;
			case 1:
				result = t1 - t2;
				op = " - ";
				break;
			case 2:
				result = t1 * t2;
				op = " * ";
				break;
			case 3:
				if (t2 == 0) {
					continue;
				} else {
					result = t1 / t2;
					op = " / ";
				}
				break;
			case 4:
				if (t2 == 0) {
					continue;
				} else {
					result = t1 % t2;
					op = " % ";
				}
				break;

			}
			sb_q.append(t1 + op + t2+" =    \t");
			sb_a.append(t1 + op + t2 + " = " + result + "\t");
			
			count++;
			if (count % 4 == 0){
				sb_q.append("\n");
				sb_a.append("\n");
			}

		}
		System.out.println(sb_q.toString());
		System.out.println(sb_a.toString());
		

	}

}
